<!DOCTYPE html>
<html>

<?php require_once("header.html"); ?>
    
<h1 id="create">TEST FORM WITH VARIABLES</h1>
    
    <hr>
    <form method="post" testBracket2.php>
        
        <div class="form-box" data-errormsg=""> 
            <label for="bracketDate"><h3>Bracket Date</h3></label>
            <input type="date" id="bracketDate" name="date" autofocus>
        </div>
        
        <div class="form-box" data-errormsg="">
            <label for="bracketType"><h3>Bracket Type</h3></label>
            <select id="bracketType" name="type" required >
                <option value="Single Elimination">Single Elimination</option>
                <option value="Double Elimination">Double Elimination</option>
                <option value="Round Robin">Round Robin</option>
                <option value="Swiss">Swiss</option>
                <option value="Two Stage">Two Stage</option>
            </select>
        </div>
        
        <div class="form-box" data-errormsg="">
            <label for="attendantNames"><h3>Attendants</h3></label>
            <input type="text" id="attendantNames" name="names" value="none"><br><br><br>
        </div>
    
        <div>
            <label for="submission"><h4>Generate Bracket</h4></label>
            <input type="submit" id="submission" formaction="Single_Elimination.php" value="Submit Form">
        </div>

        <div>
            <label for="refresher"><h4>Refresh Bracket</h4></label>
            <input type="reset" name="refresher" value="Clear Form">
        </div>
        
      </form>
    <br><br>
    <hr>
<?php require_once("footer.html"); ?>
