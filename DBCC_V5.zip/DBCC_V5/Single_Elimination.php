<!DOCTYPE html>
<?php
require_once("header.html");

//Create Variables From Form Elements
$date = $_POST['date'];
$type = $_POST['type'];
//$number = $_POST['count'];
$names = $_POST['names'];

?>
  
<section id="bracket">
    <div class="container">
    <div class="split split-one">
    <div class="round round-one current">
    <div class="round-details">Round 1<br/><span class="date">March 16</span></div>
        
        <script type="text/javascript">
            //Get the names passed via form
            var names_unparsed = String(<?php echo json_encode($names); ?>);
            var array = names_unparsed.split(",");
            
            //Define a function for an entry prototype
            function Create_Entry(el_id, att_name, bool_val) 
            {
                this.elementID = el_id;
                this.attendantName = att_name;
                this.isChecked = bool_val;
            }
            
            //Create an emptry array to place entry objects in
            var entryArray = [];
            
            //Create an entry for all the attendants entered via the form
            //Create entries using prototype, append them to end of new array
            for(i = 0; i < array.length; i++)
                {
                    var entry = new Create_Entry("void", array[i], false);
                    entryArray.push(entry);
                }
            
            
        if ((array.length % 2) == 0 && array.length > 0)
        {
            for (i = 0; i < (array.length / 2); i++) 
            {   
                entryArray[(2*i)].elementID = "myCheck" + (2*i).toString();
                document.write("<ul class=\"matchup\">");
                document.write("<li class=\"team team-top\">"+ entryArray[(2*i)].attendantName +"<span class=\"score\"><input type=\"checkbox\" id=\"myCheck"+ (2*i) +"\"  onclick=\"myFunction(this)\"><\/span><\/li>");
                
                //entryArray[(2*i)].elementID = "myCheck" + (2*i).toString();
             
                document.write("<li class=\"team team-bottom\">"+entryArray[(2*i)+1].attendantName+"<span class=\"score\"><input type=\"checkbox\" id=\"myCheck" + ((2*i)+1) + "\"  onclick=\"myFunction(this)\"><\/span><\/li>");
                document.write("<\/ul>");
                
                entryArray[(2*i)+1].elementID = "myCheck" + ((2*i)+1).toString();
            }
        } 
        else 
        {
            for (i = 0; i < Math.floor((array.length / 2)); i++) 
            {   document.write("<ul class=\"matchup\">");
                document.write("<li class=\"team team-top\">"+ entryArray[(2*i)].attendantName +"<span class=\"score\"><input type=\"checkbox\" id=\"myCheck"+ (2*i) +"\"  onclick=\"myFunction(this)\"><\/span><\/li>");
             
                entryArray[(2*i)].elementID = "myCheck" + (2*i).toString();
             
                document.write("<li class=\"team team-bottom\">"+entryArray[(2*i)+1].attendantName+"<span class=\"score\"><input type=\"checkbox\" id=\"myCheck" + ((2*i)+1) + "\"  onclick=\"myFunction(this)\"><\/span><\/li>");
                document.write("<\/ul>");
             
                entryArray[(2*i)+1].elementID = "myCheck" + ((2*i)+1).toString();
            }
            
                document.write("<ul class=\"matchup\">");
                document.write("<li class=\"team team-top\">"+ entryArray[entryArray.length - 1].attendantName +"<span class=\"score\"><input type=\"checkbox\" id=\"myCheck"+ (entryArray.length - 1) +"\"  onclick=\"myFunction(this)\"><\/span><\/li>");
                document.write("<\/ul>");
            
                entryArray[entryArray.length - 1].elementID = "myCheck" + (entryArray.length - 1).toString();
 
        } 

        var round2Entries = [];    
            
        //Update entries for Round 2
        function myFunction(elem) 
        {
            //var elementText = toString(elem.parentElement.parentElement.textContent);
            if (elem.checked == true)
            {
                //Find entry with name matching element text
                //update isChecked value to true
                //Add entry to round2 array
                for(i = 0; i < entryArray.length; i++){
                    //var tempString = entryArray[i].attendantName;
                    //if(tempString == elementText){
                        //entryArray[i].isChecked = true;
                        //round2Entries.push(entryArray[i]);
                    }
            }
            else
            {
                for(i = 0; i < round2Entries.length; i++){
                    //if(round2Entries[i].attendantName == elementText){
                    //round2Entries.splice(i, 1);
                }
            }
            
            //regenerate round 2 page section with clear and for loop
            //call function below
            //clearcontent(round_2);
            
            
            
        }
    
        //Function to clear all content of a div by ID
        function clearcontent(elementID) {
            document.getElementById(elementID).innerHTML = "";
        }
            
            

        </script>
    </div>  <!-- END ROUND ONE -->

    <div class="round round-two">
    <div class="round-details">Round 2<br/><span class="date">March 18</span></div>
        <div id="round_2">
        
        </div>
    </div>  <!-- END ROUND TWO -->

    <div class="round round-three">
    <div class="round-details">Round 3<br/><span class="date">March 20</span></div>
    </div>  <!-- END ROUND THREE -->

    <div class="round round-four">
    <div class="round-details">Round 4<br/><span class="date">March 20</span></div>
    </div>  <!-- END ROUND FOUR -->

    <div class="round round-five">
    <div class="round-details">Round 5<br/><span class="date">March 20</span></div>
    </div>  <!-- END ROUND FIVE -->

    <div class="round round-six">
    <div class="round-details">Round 6<br/><span class="date">March 20</span></div>
    </div>  <!-- END ROUND SIX -->
        
</section>
