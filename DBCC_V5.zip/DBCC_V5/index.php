<?php require_once("header.html");?>

    <h1>This is some middle section content</h1>
    <a href="index_Form.php">Create Bracket</a>
    
<?php require_once("footer.html");?>