<!DOCTYPE html>
<?php
//session_start();
//include('./dbconn.php');
//db_connect();
require_once("header.html");

//Create Variables From Form Elements
$date = $_POST['date'];
$type = $_POST['type'];
$number = $_POST['count'];
$names = $_POST['names'];

echo $date;
echo $type;
echo $number;
echo $names;

?>
  
<section id="bracket">
    <div class="container">
    <div class="split split-one">
    <div class="round round-one current">
    <div class="round-details">Round 1<br/><span class="date">March 16</span></div>
        
        <script type="text/javascript">
            var date = <?php echo $date?>;
            var type = <?php echo $type?>;
            var number =<?php echo $number?>;
            var names = <?php echo $names?>;
            
            System.out.println(date);
            System.out.println(type);
            System.out.println(number);
            System.out.println(names);
            
            var content;
            
            //create the ul element
            var a_UL document.createElement('ul');
                a_UL.id = "generatedUL";
                a_UL.class="x";

            //fill in the ul content for individual attendants
            for (i = 0; i < number; i++) { 
                content = document.createTextNode("<li class="team team-top">Duke<span class="score">76</span></li>");
                a_UL.appendChild(content);
            }
        </script>
        
    </div>  <!-- END ROUND THREE -->
    </div>
    </div>
</section>
